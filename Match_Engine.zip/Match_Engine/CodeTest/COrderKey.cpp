#include "COrderKey.h"

COrderKey::COrderKey(int id, double dPrice)
{
	this->m_id		= id;
	this->m_dPrice	= dPrice;
}

COrderKey::~COrderKey()
{

}
